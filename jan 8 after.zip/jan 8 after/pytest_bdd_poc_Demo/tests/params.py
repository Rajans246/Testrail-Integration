ULTRA_WAIT = 1
SHORT_WAIT = 5
DEFAULT_WAIT = 10
LONG_WAIT = 45
SUPER_WAIT = 180
IMPLICIT_WAIT = 10
server_name = "https://{0}.trackerwave.com/"