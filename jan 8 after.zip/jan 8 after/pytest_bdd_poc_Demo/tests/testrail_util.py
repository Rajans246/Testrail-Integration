from tests.testrail import *
from tests.testrail import APIClient

class TestRailUtil:
    testrail = None
    project = None
    suite = "TestDem"
    section = None
    testCase = None
    run = None

    str_testcaseID = None
    scenario_status = None

    @staticmethod
    def create_testrail_instance(url, username, password):
        try:
            TestRailUtil.testrail = APIClient(url)
            TestRailUtil.testrail.user = username
            TestRailUtil.testrail.password = password
            print("Testrail Instance Created")
        except Exception as e:
            print("Error:", str(e))

    # @staticmethod
    # def create_testrail_project(project_name):
    #     try:
    #         TestRailUtil.project = TestRailUtil.testrail.send_post(
    #             'add_project',
    #             {'name': project_name}
    #         )
    #         print("TestRail Project Added Successfully")
    #     except Exception as e:
    #         print("Error:", str(e))
    @staticmethod
    def create_testrail_project(project_name):
        try:
            # Get the list of projects
            projects_response = TestRailUtil.testrail.send_get('get_projects')
            projects = projects_response.get('projects', []) 
            print("projectsss")
            print(projects)

            # Check if a project with the given name already exists
            existing_project = next((project for project in projects if project['name'] == project_name), None)
            print("exist    projectttttt")
            print(existing_project)

            if existing_project:
                # Project with the given name already exists, use its ID
                print("check existing")
                TestRailUtil.project = existing_project
                print(f"TestRail Project '{project_name}' Already Exists (ID: {existing_project['id']})")
                return existing_project['id']
            else:
                # Project with the given name does not exist, create a new project
                TestRailUtil.project = TestRailUtil.testrail.send_post(
                    'add_project',
                    {'name': project_name}
                )
                print(f"TestRail Project '{project_name}' Added Successfully (ID: {TestRailUtil.project['id']})")
                return TestRailUtil.project['id']
        except Exception as e:
            print("Error:", str(e))
        



    @staticmethod
    def create_testrail_suite_test(project_id, suite_name):
        try:
            print("before start")
            suite_data = {'name': suite_name}
            if project_id:
                print("in the if before suite data")
                suite_data['project_id'] = str(project_id)  # Convert project_id to string
                print(suite_data)
                print(suite_name)
                suie_id = str(1)
                print(suie_id)
                print("suite_data fetched")
                sda ={ "project_id":suie_id,"name":"demp"}
                print(sda)
            # Add the suite using send_post
            TestRailUtil.suite = TestRailUtil.testrail.send_post(f'add_suite/{project_id}', suite_data)
            print("TestRail Suite added successfully")
            suites = TestRailUtil.testrail.send_get(f'get_suites/{project_id}')
            print("Suites after adding a new suite:")
            print(suites)
            if suites:
                new_suite = next((s for s in suites if s['name'] == suite_name), None)
                if new_suite:
                    suite_id = new_suite['id']
                    print(f"Suite ID after adding a new suite: {suite_id}")
            return suite_id
            


        except Exception as e:
            print("failed in the test suite adding")
            print("Error:", str(e))
    


    @staticmethod
    def create_testrail_section(project_id, suite_id, section_name):
        try:
            print("started in the section")
            print(project_id)
            print(type(project_id))

            print("uou yahs")
            section_data = {'name': section_name}
            print(suite_id)
            if suite_id:
                section_data['suite_id'] = int(suite_id)
            print("tet section")
            print(section_data)
            print("project id ", project_id)
            if project_id:
                section_data['project_id'] = int(project_id)
                print(section_data)
            TestRailUtil.section = TestRailUtil.testrail.send_post(f'add_section/{project_id}',section_data)
            print("TestRail Section Added Successfully")
        except Exception as e:
            print("testrail section failed")
            print("Error:", str(e))

    @staticmethod
    def create_testrail_testcases(section_id, test_case_title):
        try:
            custom_case_fields = TestRailUtil.testrail.send_get('get_case_fields')
            case_data = {'title': test_case_title, 'custom_case_fields': custom_case_fields}
            if section_id:
                case_data['section_id'] = int(section_id)
            TestRailUtil.testCase = TestRailUtil.testrail.send_post(
                'add_case',
                case_data
            )
            print("TestRail Testcase Added Successfully")
        except Exception as e:
            print("Error:", str(e))

    @staticmethod
    def create_testrail_run(project_id, suite_id, test_run_name):
        try:
            run_data = {'name': test_run_name, 'suite_id': int(suite_id)}
            if project_id:
                run_data['project_id'] = int(project_id)
            TestRailUtil.run = TestRailUtil.testrail.send_post(
                'add_run',
                run_data
            )
            print("TestRail test Run Added Successfully")
        except Exception as e:
            print("Error:", str(e))

    @staticmethod
    def add_test_result(test_run_id, test_case_id):
        try:
            if str(test_case_id) == str(TestRailUtil.str_testcaseID):
                custom_result_fields = TestRailUtil.testrail.send_get('get_result_fields')
                status_id = 1 if TestRailUtil.scenario_status == "PASSED" else 5
                result_data = {'status_id': status_id, 'custom_result_fields': custom_result_fields}
                if test_run_id:
                    result_data['run_id'] = int(test_run_id)
                    TestRailUtil.testrail.send_post(
                        'add_result_for_case',
                        int(test_case_id),
                        result_data
                    )
                    print("Testrail Run id:", test_run_id)
                    print("Test Result Added to Testrail")
        except Exception as e:
            print("Error:", str(e))


    ##############################################################################

# from tests.testrail import APIClient

# class TestRailUtil:
#     testrail = None

#     @staticmethod
#     def create_testrail_instance(url, username, password):
#         try:
#             TestRailUtil.testrail = APIClient(url)
#             TestRailUtil.testrail.user = username
#             TestRailUtil.testrail.password = password
#             print("Testrail Instance Created")
#         except Exception as e:
#             print("Error:", str(e))

#     # def __init__():
#     #     self.testrail = APIClient(url)
#     #     self.testrail.user = username
#     #     self.testrail.password = password
#     #     self.project_id = None
#     #     self.suite_id = None
#     #     self.section_id = None
#     #     self.test_case_id = None
#     #     self.run_id = None


#     def create_testrail_project(self, project_name):
#         try:
#             # Check if the project already exists
#             projects = self.testrail.send_get('get_projects')
#             existing_project = next((project for project in projects if project['name'] == project_name), None)
#             print("exist project")
#             print(existing_project)

#             if existing_project:
#                 print(f"Project '{project_name}' already exists.")
#                 self.project_id = existing_project['id']
#                 print("pro id")
#                 print(self.project_id)
#             else:
#                 # Create a new project
#                 project_data = {'name': project_name}
#                 project = self.testrail.send_post('add_project', project_data)
#                 print(f"TestRail Project '{project_name}' added successfully.")
#                 self.project_id = project['id']

#         except Exception as e:
#             print("Error:", str(e))

#     # def create_or_get_suite(self, suite_name):
#     #     try:
#     #         # Check if the suite already exists
#     #         suites = self.testrail.send_get(f'get_suites/{self.project_id}')
#     #         existing_suite = next((suite for suite in suites if suite['name'] == suite_name), None)

#     #         if existing_suite:
#     #             print(f"Suite '{suite_name}' already exists.")
#     #             self.suite_id = existing_suite['id']
#     #             print("suite_id")
#     #             print(self.suite_id)
#     #         else:
#     #             # Create a new suite
#     #             suite_data = {'name': suite_name, 'project_id': self.project_id}
#     #             print(suite_data)
#     #             suite = self.testrail.send_post(f'add_suite/{self.project_id}', suite_data)
#     #             print(f"TestRail Suite '{suite_name}' added successfully.")
#     #             self.suite_id = suite['id']

#     #     except Exception as e:
#     #         print("Error:", str(e))

#     # def create_testrail_section(self, section_name):
#     #     try:
#     #         section_data = {'name': section_name, 'suite_id': self.suite_id}
#     #         if self.project_id:
#     #             section_data['project_id'] = self.project_id
#     #         section = self.testrail.send_post('add_section', section_data)
#     #         print(f"TestRail Section '{section_name}' added successfully.")
#     #         self.section_id = section['id']

#     #     except Exception as e:
#     #         print("Error:", str(e))
            
#     def create_or_get_suite(self, suite_name):
#         try:
#             if not self.suite_id:
#                 # Create a new suite if self.suite_id is None
#                 suite_data = {'name': suite_name, 'project_id': self.project_id}
#                 suite = self.testrail.send_post(f'add_suite/{self.project_id}', suite_data)
#                 print(f"TestRail Suite '{suite_name}' added successfully.")
#                 self.suite_id = suite['id']
#             else:
#                 print(f"Suite '{suite_name}' already exists.")

#         except Exception as e:
#             print("Error:", str(e))

#     def create_testrail_section(self, section_name):
#         try:
#             if self.suite_id:
#                 section_data = {'name': section_name, 'suite_id': self.suite_id}
#                 if self.project_id:
#                     section_data['project_id'] = self.project_id
#                 section = self.testrail.send_post('add_section', section_data)
#                 print(f"TestRail Section '{section_name}' added successfully.")
#                 self.section_id = section['id']

#             else:
#                 print("Error: Suite ID is None. Create or get a suite first.")

#         except Exception as e:
#             print("Error:", str(e))

#     def create_testrail_run(self, test_run_name):
#         try:
#             if self.suite_id and self.project_id:
#                 run_data = {'name': test_run_name, 'suite_id': self.suite_id, 'project_id': self.project_id}
#                 test_run = self.testrail.send_post('add_run', run_data)
#                 print(f"TestRail Test Run '{test_run_name}' added successfully.")
#                 self.run_id = test_run['id']
#                 return self.run_id
#             else:
#                 print("Error: Suite ID or Project ID is None. Create or get a suite first.")

#         except Exception as e:
#             print("Error:", str(e))

#     def create_testrail_testcases(self, test_case_title):
#         try:
#             custom_case_fields = self.testrail.send_get('get_case_fields')
#             case_data = {'title': test_case_title, 'custom_case_fields': custom_case_fields}
#             if self.section_id:
#                 case_data['section_id'] = self.section_id
#             test_case = self.testrail.send_post('add_case', case_data)
#             print(f"TestRail Testcase '{test_case_title}' added successfully.")
#             self.test_case_id = test_case['id']

#         except Exception as e:
#             print("Error:", str(e))

#     # def create_testrail_run(self, test_run_name):
#     #     try:
#     #         run_data = {'name': test_run_name, 'suite_id': self.suite_id}
#     #         if self.project_id:
#     #             run_data['project_id'] = self.project_id
#     #         test_run = self.testrail.send_post('add_run', run_data)
#     #         print(f"TestRail Test Run '{test_run_name}' added successfully.")
#     #         self.run_id = test_run['id']
#     #         return self.run_id

#     #     except Exception as e:
#     #         print("Error:", str(e))

#     def add_test_result(self, status_id):
#         try:
#             if self.run_id and self.test_case_id:
#                 custom_result_fields = self.testrail.send_get('get_result_fields')
#                 result_data = {'status_id': status_id, 'custom_result_fields': custom_result_fields}
#                 result = self.testrail.send_post(f'add_result_for_case/{self.run_id}/{self.test_case_id}', result_data)
#                 print("Test Result added to TestRail.")

#         except Exception as e:
#             print("Error:", str(e))
